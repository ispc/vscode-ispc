#pragma once

int some_fun2();
