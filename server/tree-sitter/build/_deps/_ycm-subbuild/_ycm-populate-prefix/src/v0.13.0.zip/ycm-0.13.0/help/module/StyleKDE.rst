.. cmake-module:: ../../style-modules/StyleKDE.cmake
