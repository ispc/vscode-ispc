.. cmake-module:: ../../modules/AddUninstallTarget.cmake
