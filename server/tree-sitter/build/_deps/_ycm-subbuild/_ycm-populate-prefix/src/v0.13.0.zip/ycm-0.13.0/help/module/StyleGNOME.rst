.. cmake-module:: ../../style-modules/StyleGNOME.cmake
