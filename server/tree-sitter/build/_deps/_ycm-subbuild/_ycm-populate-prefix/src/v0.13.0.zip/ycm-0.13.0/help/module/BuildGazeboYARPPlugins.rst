.. cmake-module:: ../../build-modules/BuildGazeboYARPPlugins.cmake
