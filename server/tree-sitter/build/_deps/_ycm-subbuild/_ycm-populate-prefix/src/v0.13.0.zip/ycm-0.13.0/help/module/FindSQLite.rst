.. cmake-module:: ../../find-modules/FindSQLite.cmake
