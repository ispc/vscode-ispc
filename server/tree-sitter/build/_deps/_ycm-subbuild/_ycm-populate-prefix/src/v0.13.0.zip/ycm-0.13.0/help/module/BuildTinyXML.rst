.. cmake-module:: ../../build-modules/BuildTinyXML.cmake
