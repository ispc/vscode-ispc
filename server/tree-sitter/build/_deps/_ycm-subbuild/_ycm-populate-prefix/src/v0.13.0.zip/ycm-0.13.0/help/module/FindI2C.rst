.. cmake-module:: ../../find-modules/FindI2C.cmake
