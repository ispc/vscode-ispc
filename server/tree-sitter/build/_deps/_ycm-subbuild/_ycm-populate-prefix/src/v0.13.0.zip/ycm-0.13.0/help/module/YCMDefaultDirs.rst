.. cmake-module:: ../../deprecated/YCMDefaultDirs.cmake
