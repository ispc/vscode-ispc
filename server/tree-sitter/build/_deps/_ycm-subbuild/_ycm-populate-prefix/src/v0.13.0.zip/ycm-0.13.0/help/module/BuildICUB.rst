.. cmake-module:: ../../build-modules/BuildICUB.cmake
