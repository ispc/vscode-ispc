.. cmake-module:: ../../find-modules/FindTinyXML.cmake
