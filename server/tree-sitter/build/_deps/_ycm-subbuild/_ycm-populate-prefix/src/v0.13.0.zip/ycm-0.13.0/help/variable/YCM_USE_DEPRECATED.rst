YCM_USE_DEPRECATED
------------------

Enable YCM deprecated modules.

Some YCM modules have been deprecated, and should not be used in new
code.
Nonetheless they are available for backwards compatibility and can be
still used in old code by setting this variable to true.
