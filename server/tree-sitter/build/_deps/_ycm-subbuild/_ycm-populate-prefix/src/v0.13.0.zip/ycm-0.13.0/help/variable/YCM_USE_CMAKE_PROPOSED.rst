YCM_USE_CMAKE_PROPOSED
----------------------

Use YCM patched version of modules from CMake.

YCM provides a few modules that are available with CMake, but with a few
patches applied.
These are not automatically used, in order to let the user choose
whether to use the original or the patched version.
Enable this variable to use the YCM version of these modules.
