.. cmake-module:: ../../modules/ExtractVersion.cmake
