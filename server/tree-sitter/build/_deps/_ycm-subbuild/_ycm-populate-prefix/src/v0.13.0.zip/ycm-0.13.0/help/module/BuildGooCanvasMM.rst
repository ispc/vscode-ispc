.. cmake-module:: ../../build-modules/BuildGooCanvasMM.cmake
