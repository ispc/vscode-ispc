.. cmake-module:: ../../find-modules/FindFreenect.cmake
