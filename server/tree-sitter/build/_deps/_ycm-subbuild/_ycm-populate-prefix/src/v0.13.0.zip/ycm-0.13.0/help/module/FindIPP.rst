.. cmake-module:: ../../find-modules/FindIPP.cmake
