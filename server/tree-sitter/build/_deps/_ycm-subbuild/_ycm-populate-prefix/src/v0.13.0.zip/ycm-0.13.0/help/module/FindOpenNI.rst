.. cmake-module:: ../../find-modules/FindOpenNI.cmake
