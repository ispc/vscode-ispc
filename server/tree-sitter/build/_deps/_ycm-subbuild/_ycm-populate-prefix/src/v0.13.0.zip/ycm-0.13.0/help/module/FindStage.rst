.. cmake-module:: ../../find-modules/FindStage.cmake
