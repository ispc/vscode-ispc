.. cmake-module:: ../../find-modules/FindGooCanvasMM.cmake
