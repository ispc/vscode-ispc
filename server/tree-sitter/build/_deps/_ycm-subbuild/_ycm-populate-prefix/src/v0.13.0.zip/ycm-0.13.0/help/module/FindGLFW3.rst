.. cmake-module:: ../../find-modules/FindGLFW3.cmake
