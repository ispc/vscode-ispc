.. cmake-module:: ../../find-modules/FindGSL.cmake
