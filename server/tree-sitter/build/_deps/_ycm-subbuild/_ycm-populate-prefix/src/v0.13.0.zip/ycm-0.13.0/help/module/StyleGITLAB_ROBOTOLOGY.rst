.. cmake-module:: ../../style-modules/StyleGITLAB_ROBOTOLOGY.cmake
