YCM_USE_CMAKE
-------------

Enable or disable all ``YCM_USE_CMAKE_`` variables (default ``ON``).

.. seealso::
    :variable:`YCM_USE_CMAKE_<VERSION>`,
    :variable:`YCM_USE_CMAKE_NEXT`.
    :variable:`YCM_USE_CMAKE_PROPOSED`.

