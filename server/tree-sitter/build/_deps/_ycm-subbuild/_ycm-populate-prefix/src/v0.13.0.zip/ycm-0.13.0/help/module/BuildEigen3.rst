.. cmake-module:: ../../build-modules/BuildEigen3.cmake
