.. cmake-module:: ../../find-modules/FindAtlas.cmake
