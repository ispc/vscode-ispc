.. cmake-module:: ../../find-modules/FindGLUT.cmake
