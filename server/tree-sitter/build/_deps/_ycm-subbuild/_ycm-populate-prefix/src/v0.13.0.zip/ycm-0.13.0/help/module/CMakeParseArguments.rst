.. cmake-module:: ../../cmake-next/proposed/CMakeParseArguments.cmake
