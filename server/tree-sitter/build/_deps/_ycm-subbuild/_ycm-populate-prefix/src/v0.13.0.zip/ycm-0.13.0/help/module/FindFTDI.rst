.. cmake-module:: ../../find-modules/FindFTDI.cmake
