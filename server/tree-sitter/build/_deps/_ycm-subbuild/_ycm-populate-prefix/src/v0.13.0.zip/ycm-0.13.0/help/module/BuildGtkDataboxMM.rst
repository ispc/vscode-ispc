.. cmake-module:: ../../build-modules/BuildGtkDataboxMM.cmake
