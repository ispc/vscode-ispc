.. cmake-module:: ../../find-modules/FindOpenGL.cmake
