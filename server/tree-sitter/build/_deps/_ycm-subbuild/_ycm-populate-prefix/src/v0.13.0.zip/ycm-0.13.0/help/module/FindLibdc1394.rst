.. cmake-module:: ../../find-modules/FindLibdc1394.cmake
