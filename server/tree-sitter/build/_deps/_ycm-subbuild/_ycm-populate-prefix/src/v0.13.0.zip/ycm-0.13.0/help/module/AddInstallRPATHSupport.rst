.. cmake-module:: ../../modules/AddInstallRPATHSupport.cmake
