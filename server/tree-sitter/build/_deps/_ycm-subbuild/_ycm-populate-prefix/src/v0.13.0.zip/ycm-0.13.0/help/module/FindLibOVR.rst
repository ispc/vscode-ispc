.. cmake-module:: ../../find-modules/FindLibOVR.cmake
