.. cmake-module:: ../../modules/YCMEPHelper.cmake
