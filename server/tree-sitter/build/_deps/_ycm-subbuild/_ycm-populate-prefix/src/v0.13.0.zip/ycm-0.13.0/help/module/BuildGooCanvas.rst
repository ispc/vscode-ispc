.. cmake-module:: ../../build-modules/BuildGooCanvas.cmake
