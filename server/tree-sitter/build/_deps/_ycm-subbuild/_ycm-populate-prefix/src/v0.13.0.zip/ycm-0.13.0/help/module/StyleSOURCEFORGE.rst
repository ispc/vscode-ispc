.. cmake-module:: ../../style-modules/StyleSOURCEFORGE.cmake
