.. cmake-module:: ../../find-modules/Findassimp.cmake
