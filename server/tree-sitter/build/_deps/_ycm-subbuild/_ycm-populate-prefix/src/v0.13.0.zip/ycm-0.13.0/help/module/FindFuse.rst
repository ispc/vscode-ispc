.. cmake-module:: ../../find-modules/FindFuse.cmake
