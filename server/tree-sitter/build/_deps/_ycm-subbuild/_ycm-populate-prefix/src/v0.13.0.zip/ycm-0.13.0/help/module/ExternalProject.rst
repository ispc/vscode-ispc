.. cmake-module:: ../../cmake-next/proposed/ExternalProject.cmake
