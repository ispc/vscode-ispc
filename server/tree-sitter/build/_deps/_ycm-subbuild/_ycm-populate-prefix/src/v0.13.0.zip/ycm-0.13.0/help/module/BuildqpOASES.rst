.. cmake-module:: ../../build-modules/BuildqpOASES.cmake
