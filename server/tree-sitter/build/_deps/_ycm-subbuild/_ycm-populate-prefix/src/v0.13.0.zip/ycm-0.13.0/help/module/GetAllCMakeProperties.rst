.. cmake-module:: ../../modules/GetAllCMakeProperties.cmake
