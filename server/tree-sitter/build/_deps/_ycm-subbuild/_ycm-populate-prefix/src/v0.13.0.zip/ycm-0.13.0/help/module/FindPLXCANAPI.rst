.. cmake-module:: ../../find-modules/FindPLXCANAPI.cmake
