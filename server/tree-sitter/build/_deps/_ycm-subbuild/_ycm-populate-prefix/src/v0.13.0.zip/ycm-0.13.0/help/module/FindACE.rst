.. cmake-module:: ../../find-modules/FindACE.cmake
