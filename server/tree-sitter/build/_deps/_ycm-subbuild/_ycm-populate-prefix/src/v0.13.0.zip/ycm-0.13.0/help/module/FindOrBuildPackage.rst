.. cmake-module:: ../../modules/FindOrBuildPackage.cmake
