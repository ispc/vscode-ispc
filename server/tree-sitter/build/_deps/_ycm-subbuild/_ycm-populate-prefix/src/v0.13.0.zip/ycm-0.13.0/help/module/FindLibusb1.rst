.. cmake-module:: ../../find-modules/FindLibusb1.cmake
