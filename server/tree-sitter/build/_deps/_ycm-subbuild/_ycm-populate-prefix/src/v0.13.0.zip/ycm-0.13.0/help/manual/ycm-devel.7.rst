.. cmake-manual-description: YCM Developer Manual

ycm-devel(7)
************

.. only:: html or latex

   .. contents::

YCM Developer Manual
====================

TODO: This is the manual for people who want to modify YCM


TODO How to test changes locally::


  set(YCM_BOOTSTRAP_BASE_ADDRESS file:///opt/iit/src/ycm CACHE STRING "")
  set(YCM_BOOTSTRAP_VERBOSE TRUE)
  set(YCM_SKIP_HASH_CHECK TRUE)

  set(YCM_STYLE LOCAL)
  set(YCM_REPOSITORY file:///opt/iit/src/ycm)


TODO How to generate the documentation

TODO How to re-generate the documentation and upload it on github gh-pages

Maintainer Mode
---------------

:variable:`YCM_MAINTAINER_MODE`
