.. cmake-module:: ../../find-modules/FindLibedit.cmake
