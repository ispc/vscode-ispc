.. cmake-module:: ../../find-modules/FindCFW2CANAPI.cmake
