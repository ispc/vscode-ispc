.. cmake-module:: ../../find-modules/FindGtkDatabox.cmake
