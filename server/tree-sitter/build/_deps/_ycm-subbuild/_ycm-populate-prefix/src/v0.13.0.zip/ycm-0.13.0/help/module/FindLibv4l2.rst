.. cmake-module:: ../../find-modules/FindLibv4l2.cmake
