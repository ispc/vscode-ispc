.. cmake-module:: ../../find-modules/FindIPOPT.cmake
