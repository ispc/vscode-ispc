.. cmake-module:: ../../build-modules/BuildGtkDatabox.cmake
