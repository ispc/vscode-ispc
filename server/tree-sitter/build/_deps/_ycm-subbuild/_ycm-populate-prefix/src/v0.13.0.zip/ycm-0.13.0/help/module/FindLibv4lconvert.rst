.. cmake-module:: ../../find-modules/FindLibv4lconvert.cmake
