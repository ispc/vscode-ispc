.. cmake-module:: ../../build-modules/BuildYARP.cmake
