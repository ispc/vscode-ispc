.. cmake-module:: ../../modules/ReplaceImportedTargets.cmake
