.. cmake-module:: ../../style-modules/StyleNONE.cmake
