.. cmake-module:: ../../find-modules/FindGooCanvas.cmake
