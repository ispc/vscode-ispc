.. cmake-module:: ../../find-modules/FindYamlCpp.cmake
