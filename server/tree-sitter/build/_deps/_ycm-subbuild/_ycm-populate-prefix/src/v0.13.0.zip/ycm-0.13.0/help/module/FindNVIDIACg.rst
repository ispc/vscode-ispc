.. cmake-module:: ../../find-modules/FindNVIDIACg.cmake
