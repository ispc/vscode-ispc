.. cmake-module:: ../../style-modules/StyleBITBUCKET.cmake
