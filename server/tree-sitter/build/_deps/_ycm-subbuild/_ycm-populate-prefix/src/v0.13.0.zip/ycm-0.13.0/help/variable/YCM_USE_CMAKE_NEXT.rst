YCM_USE_CMAKE_NEXT
------------------

Use CMake modules imported from CMake git repository.
