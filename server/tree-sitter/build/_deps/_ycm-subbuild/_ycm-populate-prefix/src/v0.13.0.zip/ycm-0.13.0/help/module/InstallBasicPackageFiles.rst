.. cmake-module:: ../../modules/InstallBasicPackageFiles.cmake
