.. cmake-module:: ../../find-modules/FindReadline.cmake
