.. cmake-module:: ../../style-modules/StyleLOCAL.cmake
