.. cmake-manual-description: YCM Variables Reference

ycm-variables(7)
****************

.. only:: html or latex

   .. contents::

Variables that Change Behavior
==============================

.. toctree::
   :maxdepth: 1

   /variable/YCM_USE_3RDPARTY
   /variable/YCM_USE_CMAKE
   /variable/YCM_USE_CMAKE_VERSION
   /variable/YCM_USE_CMAKE_NEXT
   /variable/YCM_USE_CMAKE_PROPOSED
   /variable/YCM_USE_DEPRECATED
