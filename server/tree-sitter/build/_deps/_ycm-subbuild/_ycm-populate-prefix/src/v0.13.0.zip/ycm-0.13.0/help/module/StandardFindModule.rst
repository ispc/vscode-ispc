.. cmake-module:: ../../modules/StandardFindModule.cmake
