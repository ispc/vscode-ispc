.. cmake-module:: ../../modules/GitInfo.cmake
