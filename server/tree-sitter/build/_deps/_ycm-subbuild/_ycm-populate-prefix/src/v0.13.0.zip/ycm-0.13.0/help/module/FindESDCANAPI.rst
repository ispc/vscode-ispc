.. cmake-module:: ../../find-modules/FindESDCANAPI.cmake
