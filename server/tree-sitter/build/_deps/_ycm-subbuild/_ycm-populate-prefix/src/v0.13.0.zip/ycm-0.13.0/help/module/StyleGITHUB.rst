.. cmake-module:: ../../style-modules/StyleGITHUB.cmake
