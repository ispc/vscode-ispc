.. cmake-module:: ../../find-modules/FindqpOASES.cmake
