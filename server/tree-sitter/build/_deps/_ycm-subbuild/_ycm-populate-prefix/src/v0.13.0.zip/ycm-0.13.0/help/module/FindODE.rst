.. cmake-module:: ../../find-modules/FindODE.cmake
