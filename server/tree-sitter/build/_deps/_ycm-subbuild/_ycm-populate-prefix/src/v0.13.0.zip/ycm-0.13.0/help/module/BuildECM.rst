.. cmake-module:: ../../build-modules/BuildECM.cmake
