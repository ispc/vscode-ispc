.. cmake-module:: ../../find-modules/FindOpenCV.cmake
