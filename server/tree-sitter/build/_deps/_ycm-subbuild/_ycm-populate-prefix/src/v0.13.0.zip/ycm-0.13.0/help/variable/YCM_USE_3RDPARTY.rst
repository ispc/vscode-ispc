YCM_USE_3RDPARTY
----------------

Use modules downloaded from 3rd party projects.
