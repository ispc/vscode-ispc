# cmake-forward-arguments

Provides a utility function to forward cherry-picked variable-length argument
lists from one function to another in CMake.
